# m73-efi
lenovo tiny m73 opencore efi

CPU：i5-4590T \
内存：16g \
网卡：BCM94360HMB

**注意：** 使用此efi，请使用occ重新生成自己的序列号
